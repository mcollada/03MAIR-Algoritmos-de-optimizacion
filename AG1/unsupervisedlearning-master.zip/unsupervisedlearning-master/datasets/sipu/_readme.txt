Obtenidos de:

http://cs.joensuu.fi/sipu/datasets/
